<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfileByDomainsController extends Controller
{
    //
}
